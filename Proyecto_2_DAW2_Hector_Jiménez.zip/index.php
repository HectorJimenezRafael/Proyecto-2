<?php 
echo "<script>window.location.href ='view/login.php'</script>";

