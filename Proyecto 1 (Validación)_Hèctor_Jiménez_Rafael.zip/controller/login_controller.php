
<?php

//require_once '../include/config/config.php';
require_once '../include/connection.php';
require_once '../include/func.php';

// recogemos los campos del formulario

$nombre=$_POST['usuario_nombre'];
$pass=$_POST['contra_usu'];

// encriptamos la contraseña
$pass = hash('sha256', $pass);


if (!validar($nombre, $pass, $conexion)) {
    ?>
    <script>location.href = '../view/login.php?error=true'</script>
    <?php

}


// una vez el nombre y la contraseña se correspondan iniciaremos la sesión
iniciar_sesion($nombre, $conexion);

if (  $_SESSION['usuario_tipo']==1) {
    ?>
<script>location.href = '../view/inicio.php'</script>
     <?php
} elseif ($_SESSION['usuario_tipo']==2) {
    ?>
    <script>location.href = '../view/inicio.php'</script>
         <?php
}
?>




