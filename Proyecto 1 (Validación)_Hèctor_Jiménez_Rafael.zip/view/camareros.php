<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<?php
  require_once("../include/connection.php");

$sql="SELECT * FROM tbl_usuarios WHERE usuario_tipo LIKE '1' ";

$resultado=mysqli_query($conexion, $sql);

?>
<table>
<?php
foreach ($resultado as $persona) {
  

    ?>
 <?php echo $persona['usuario_nombre'];?>

 <?php echo $persona['Apellido'];?>
 <br>
    <?php

    
}

?>







</table>


</body>
</html>