<?php

require_once("../include/connection.php");
require_once ('../model/mesa.php');

$mesa_sele=$_POST['mesa_sele'];

$sitios_n=$_POST['sitios_n'];

$sql="UPDATE tbl_recurso SET `capacidad`=$sitios_n WHERE `id`=$mesa_sele ";

$resultado=mysqli_query($conexion, $sql);


echo "<script>location.href='crear.php?'</script>";