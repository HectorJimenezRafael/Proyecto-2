<<<<<<< HEAD
# P1_Reserva_de_taules
Integrantes:
Oscar
Hector
Sergio
Raul
=======
# P1_Reserva_de_taules 🪑 ✅ 🔧
Integrantes 🧑‍🦱: Oscar, Hector, Sergio y Raul


## **OBJETIVO DEL PROYECTO**

Crear una web 💻 donde los usuarios representarán camareros de un restaurante 👨‍🍳  o bar dondé podrán ver todas las mesas disponibles de dicho restaurante. Estos usuarios podrán hacer dos cosas: la primera es reservar 🔴 una mesa para que quede deshabilitada y no se puede reservar por otros clientes  hasta que un usuario de la web haya finalizado la reserva 🟢 y la segunda cosa que podrán hacer será poner una incidencia 🟡 cuando una mesa sea imposible que haya clientes 🧑‍🤝‍🧑 esta mesa estará totalmente suspendida hasta que un usuario de mantenimiento finalize el problema ⚠️ de la incidencia. También en la web se dispondrá de un apartado de estadísticas 🔂.



## **Distinguir el estado de la mesa**
```
Libre o disponible: verde 🟢

Ocupada o reservada: rojo 🔴

Averiada o estropeada: amarillo 🟡
```

## **Tipos de usuarios y sus funciones**

```
Camarero 💁🪑 : podrá reservar mesas, finalizar reservas, visualizar un mapa del restaurante 
y poner una incidencia deshabilitando la mesa.


Personal de mantenimiento👷‍♂️⚠️ : podrá finalizar una incidencia habilitando la mesa para ser reservada 
y visualizar un mapa del restaurante
```


## **FUNCIONAMIENTO DE LA WEB AXIOS**

`¿Cómo se usa Axios?`
Axios es una librería JavaScript que puede ejecutarse en el navegador y que nos permite hacer sencillas las operaciones como cliente HTTP, por lo que podremos configurar y realizar solicitudes a un servidor y recibiremos respuestas fáciles de procesar.

## **Estadísticas de la web**

Dependiendo que tipo de usuario seas podrás ver determinadas estadíticas

| Camarero 💁🪑  | Personal de mantenimiento👷‍♂️⚠️ |  
| ------|------|
| ![image] | |

>>>>>>> b2e36f17cab980312b134cd0f1624437d3d81037
