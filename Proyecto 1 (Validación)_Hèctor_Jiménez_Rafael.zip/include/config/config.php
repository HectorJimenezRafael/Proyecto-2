<?php

// Constantes base de datos
const BD = [
    'servidor' => 'localhost',
    'usuario' => 'root',
    'password' => '',
    'bd' => 'bd_p1',
];


// Constantes usuario
const USUARIO = [
    'tabla' => 'tbl_usuarios',
    'id' => 'id',
    'nombre_usu' => 'usuario_nombre',
    'pass_usu' => 'usuario_password',
    'tipo_usu' => 'usuario_tipo',
];